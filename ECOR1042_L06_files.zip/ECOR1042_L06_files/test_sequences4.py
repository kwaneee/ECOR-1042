"""
ECOR 1042
Lecture 6 Fibonacci example, test program

Last edited: March 12, 2025
"""

from sequences import fibonacci

def test_fibonacci() -> tuple[int]:
   test_values = [1, 2, 3, 5]
   expected_output = [1, 1, 2, 5]
   tests_pass = 0
   tests_fail = 0
   for i in range(len(test_values)):
       try:
           assert fibonacci(test_values[i]) == expected_output[i], \
                'Incorrect value for fibonacci(' + str(test_values[i]) + ')'
           tests_pass += 1
       except AssertionError as msg:
           print(msg)
           tests_fail += 1
   return (tests_pass, tests_fail)

if __name__ == '__main__':
   passed, failed = test_fibonacci()
   print(passed, 'tests passed,', failed, 'tests failed')
