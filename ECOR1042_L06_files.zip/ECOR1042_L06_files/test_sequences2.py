"""
ECOR 1042
Lecture 6 Fibonacci example, test program

Last edited: March 12, 2025
"""

from sequences import fibonacci

def test_fibonacci() -> int:
   test_values = [1, 2, 3, 5]
   expected_output = [1, 1, 2, 5]
   tests = 0
   for i in range(len(test_values)):
       assert fibonacci(test_values[i]) == expected_output[i], \
         'Incorrect value for fibonacci(' + str(test_values[i]) + ')'
       tests += 1
   return tests

if __name__ == '__main__':
   print('All test pass. ',test_fibonacci(), 'tests executed')




