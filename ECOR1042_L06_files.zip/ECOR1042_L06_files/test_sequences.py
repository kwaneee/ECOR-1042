"""
ECOR 1042
Lecture 6 Fibonacci example, test program

Last edited: March 12, 2025
"""

from sequences import fibonacci

def test_fibonacci() -> int:
   tests = 0
   assert fibonacci(1) == 1, 'Wrong value for fibonacci(1)'
   tests += 1
   assert fibonacci(2) == 1, 'Wrong value for fibonacci(2)'
   tests += 1
   assert fibonacci(3) == 2, 'Wrong value for fibonacci(3)'
   tests += 1
   assert fibonacci(5) == 5, 'Wrong value for fibonacci(5)'
   tests += 1
   return tests

if __name__ == '__main__':
   print('All test pass. ', test_fibonacci(), 'tests executed')



